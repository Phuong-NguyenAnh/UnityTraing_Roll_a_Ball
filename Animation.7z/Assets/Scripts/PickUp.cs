﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PickUp : MonoBehaviour {
    public bool isDie;
    
    private void Start() {
        var rnd = new System.Random();
        int color = rnd.Next(1, 4);
        GetComponent<Renderer> ().material.color = new Color (color % 2, color % 3, 0, 1);
    }

    public void Die() {
        isDie = true;
        GetComponent<Animator>().SetTrigger("Die");
    }

    public void DieFinish() {
        Destroy(gameObject);
    }
}